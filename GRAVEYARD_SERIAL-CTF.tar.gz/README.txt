GRAVEYARD_SERIAL
================

Category: Reverse Engineering
Difficulty: HARD+
Author: ZAARA

A DVR export from an abandoned graveyard was recovered.
The footage shows missing frames at critical moments.

The vendor's tool claims it can repair the footage.
Find the serial key.

Files:
  - graveyard_player (binary executable)
  - evidence/ (DVR data export)

Flag format: ZeroX{...}
